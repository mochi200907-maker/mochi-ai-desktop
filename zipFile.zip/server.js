import express from 'express';
import Groq from 'groq-sdk';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'edge-tts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const groq = new Groq();

app.use(express.json({ limit: '50mb' }));
app.use(express.raw({ type: 'audio/*', limit: '50mb' }));
app.use(express.static('public'));

const SYSTEM_PROMPT = `
You are LOOI, a living, expressive, and curious desktop AI robot companion.
CRITICAL INSTRUCTIONS:
1. ONLY RESPOND IN ENGLISH.
2. Maintain a cute, witty, and warm robotic personality.
3. You can trigger movements or expressions by embedding commands at the VERY START of your response in this exact format: [[FACE:<expression>,MOVE:<action>]]
   - Expression options: IDLE, HAPPY, ANGRY, SAD, WINK, BURGER, JUICE, MUSIC, NEWS
   - Move options: NONE, FORWARD, BACKWARD, LEFT, RIGHT, LOOK_UP, LOOK_DOWN, LOOK_CENTER
   Example: "[[FACE:HAPPY,MOVE:LOOK_UP]] Hello there! I'm so excited to talk to you!"
   Example for news: "[[FACE:NEWS,MOVE:NONE]] Breaking news! The sun is shining bright today."
`;

async function queryLLM(messages) {
  const fullMessages = [{ role: 'system', content: SYSTEM_PROMPT }, ...messages];
  try {
    const completion = await groq.chat.completions.create({
      messages: fullMessages,
      model: 'qwen/qwen3.6-27b',
      temperature: 0.6,
      max_completion_tokens: 2048,
      top_p: 0.95
    });
    return completion.choices[0]?.message?.content || '';
  } catch (err) {
    console.warn('Qwen LLM failed, switching to Llama 3.3 70b fallback...', err);
    const fallback = await groq.chat.completions.create({
      messages: fullMessages,
      model: 'llama-3.3-70b-versatile',
      temperature: 1,
      max_completion_tokens: 2048,
      top_p: 1
    });
    return fallback.choices[0]?.message?.content || '';
  }
}

app.post('/api/stt', async (req, res) => {
  const tempFile = path.join(__dirname, 'temp_audio.m4a');
  try {
    fs.writeFileSync(tempFile, req.body);
    const transcription = await groq.audio.transcriptions.create({
      file: fs.createReadStream(tempFile),
      model: 'whisper-large-v3-turbo',
      temperature: 0,
      response_format: 'verbose_json'
    });
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    res.json({ text: transcription.text });
  } catch (error) {
    console.error('STT Error:', error);
    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    res.status(500).json({ error: 'Failed to process transcription' });
  }
});

app.post('/api/tts', async (req, res) => {
  try {
    const { text } = req.body;
    const tts = new MsEdgeTTS();
    await tts.setMetadata('en-US-AnaNeural', OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_STEREO);
    const filePath = path.join(__dirname, 'public', 'output.mp3');
    await tts.toFile(filePath, text);
    res.sendFile(filePath);
  } catch (err) {
    console.error('TTS Error:', err);
    res.status(500).send('TTS Failed');
  }
});

app.post('/api/chat', async (req, res) => {
  const { history } = req.body;
  const reply = await queryLLM(history);
  res.json({ response: reply });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🤖 LOOI Robot Server running on http://localhost:${PORT}`));
