#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <ESP32Servo.h>

#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

#define MOTOR_A1 12
#define MOTOR_A2 13
#define MOTOR_B1 14
#define MOTOR_B2 27
#define SERVO_PIN 25

Servo headServo;
int currentAngle = 90;
unsigned long lastIdleMove = 0;

void setupMotors() {
  pinMode(MOTOR_A1, OUTPUT);
  pinMode(MOTOR_A2, OUTPUT);
  pinMode(MOTOR_B1, OUTPUT);
  pinMode(MOTOR_B2, OUTPUT);
}

void stopMotors() {
  digitalWrite(MOTOR_A1, LOW); digitalWrite(MOTOR_A2, LOW);
  digitalWrite(MOTOR_B1, LOW); digitalWrite(MOTOR_B2, LOW);
}

void moveForward() {
  digitalWrite(MOTOR_A1, HIGH); digitalWrite(MOTOR_A2, LOW);
  digitalWrite(MOTOR_B1, HIGH); digitalWrite(MOTOR_B2, LOW);
}

void moveBackward() {
  digitalWrite(MOTOR_A1, LOW); digitalWrite(MOTOR_A2, HIGH);
  digitalWrite(MOTOR_B1, LOW); digitalWrite(MOTOR_B2, HIGH);
}

void turnLeft() {
  digitalWrite(MOTOR_A1, LOW); digitalWrite(MOTOR_A2, HIGH);
  digitalWrite(MOTOR_B1, HIGH); digitalWrite(MOTOR_B2, LOW);
}

void turnRight() {
  digitalWrite(MOTOR_A1, HIGH); digitalWrite(MOTOR_A2, LOW);
  digitalWrite(MOTOR_B1, LOW); digitalWrite(MOTOR_B2, HIGH);
}

void setHeadAngle(int angle) {
  angle = constrain(angle, 45, 135);
  headServo.write(angle);
  currentAngle = angle;
}

class CommandCallback: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
      String value = pCharacteristic->getValue().c_str();
      if (value.length() > 0) {
        Serial.print("Received Command: ");
        Serial.println(value);

        if (value == "FORWARD") { moveForward(); delay(800); stopMotors(); }
        else if (value == "BACKWARD") { moveBackward(); delay(800); stopMotors(); }
        else if (value == "LEFT") { turnLeft(); delay(400); stopMotors(); }
        else if (value == "RIGHT") { turnRight(); delay(400); stopMotors(); }
        else if (value == "LOOK_UP") { setHeadAngle(120); }
        else if (value == "LOOK_DOWN") { setHeadAngle(60); }
        else if (value == "LOOK_CENTER") { setHeadAngle(90); }
      }
    }
};

void setup() {
  Serial.begin(115200);
  setupMotors();
  headServo.attach(SERVO_PIN);
  setHeadAngle(90);

  BLEDevice::init("LOOI_ESP32_ROBOT");
  BLEServer *pServer = BLEDevice::createServer();
  BLEService *pService = pServer->createService(SERVICE_UUID);
  BLECharacteristic *pCharacteristic = pService->createCharacteristic(
                                         CHARACTERISTIC_UUID,
                                         BLECharacteristic::PROPERTY_READ |
                                         BLECharacteristic::PROPERTY_WRITE
                                       );

  pCharacteristic->setCallbacks(new CommandCallback());
  pService->start();
  
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->start();
  Serial.println("ESP32 BLE Robot Ready & Advertising!");
}

void handleIdleBehavior() {
  if (millis() - lastIdleMove > 4000) {
    lastIdleMove = millis();
    int randomAction = random(0, 5);

    switch (randomAction) {
      case 0: setHeadAngle(random(75, 105)); break;
      case 1: turnLeft(); delay(150); stopMotors(); break;
      case 2: turnRight(); delay(150); stopMotors(); break;
      case 3: setHeadAngle(90); break;
      default: break;
    }
  }
}

void loop() {
  handleIdleBehavior();
  delay(20);
}
